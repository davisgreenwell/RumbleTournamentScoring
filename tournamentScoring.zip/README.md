low key just put the dll in the rumble mods folder. press r to reset
score. score will auto reset when gym scene is loaded. \@davisgreenwell
on discord if you need help.
